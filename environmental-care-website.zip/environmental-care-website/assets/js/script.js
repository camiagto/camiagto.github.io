document.getElementById('helpButton').addEventListener('click', function () {
    alert('¿Necesitas ayuda? Contáctanos a través del formulario.');
});